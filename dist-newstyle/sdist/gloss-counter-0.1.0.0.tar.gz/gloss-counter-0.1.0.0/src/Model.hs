-- | This module contains the data types
--   which represent the state of the game
module Model where

import Gloss

type Health     = Int
type Score      = Int
type Time       = Float 

type Coordinate = Float
data Point      = Point Coordinate Coordinate
data Vector     = Vector Coordinate Coordinate

instance Eq Vector where 
  Vector x1 y1 == Vector x2 y2 = (x1=x2 && y1=y2)

data InfoToShow = ShowNothing
                | ShowANumber Int
                | ShowAChar   Char

nO_SECS_BETWEEN_CYCLES :: Float
nO_SECS_BETWEEN_CYCLES = 5

data GameState = GameState {
                   infoToShow  :: InfoToShow
                 , elapsedTime :: Float
                 }

data Player = Player {
                positionPlayer    :: Gloss.Point,
                sizePlayer        :: Float,
                velocityPlayer    :: Gloss.Vector,
                healthPlayer      :: Health
                }

data Enemy = Enemy {
                positionEnemy    :: Gloss.Point,
                sizeEnemy        :: Float,
                velocityEnemy    :: Gloss.Vector,
                healthEnemy      :: Health
                }

initialState :: GameState
initialState = GameState ShowNothing 0